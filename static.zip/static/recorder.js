document.addEventListener("DOMContentLoaded", function () {

    let mediaRecorder = null;
    let audioChunks = [];
    let timerInterval = null;
    let seconds = 0;
    let isRecording = false;

    const recordBtn = document.getElementById("recordBtn");
    const statusText = document.getElementById("recordStatus");

    if (!statusText) {
        console.error("recordStatus element not found!");
        return;
    }
    const recordedAudioInput = document.getElementById("recordedAudio");

    if (!recordBtn) return; // safety check

    function formatTime(sec) {
        let mins = Math.floor(sec / 60);
        let secs = sec % 60;
        return String(mins).padStart(2, "0") + ":" +
               String(secs).padStart(2, "0");
    }

    recordBtn.addEventListener("click", async function () {

        // START RECORDING
        if (!isRecording) {

            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];
                seconds = 0;

                mediaRecorder.ondataavailable = function (event) {
                    if (event.data.size > 0) {
                        audioChunks.push(event.data);
                    }
                };

                mediaRecorder.onstop = function () {

                    clearInterval(timerInterval);

                    const audioBlob = new Blob(audioChunks, { type: "audio/webm" });
                    const reader = new FileReader();

                    reader.onloadend = function () {
                        recordedAudioInput.value = reader.result;
                    };

                    reader.readAsDataURL(audioBlob);

                    statusText.textContent = "✅ Saved (" + formatTime(seconds) + ")";
                    recordBtn.textContent = "🎤 Start Recording";
                    recordBtn.style.backgroundColor = "";
                    isRecording = false;
                };

                mediaRecorder.start();
                isRecording = true;

                recordBtn.textContent = "⏹ Stop Recording";
                recordBtn.style.backgroundColor = "red";

                statusText.textContent = "🔴 Recording... 00:00";

                timerInterval = setInterval(function () {
                    seconds++;
                    statusText.textContent =
                        "🔴 Recording... " + formatTime(seconds);
                }, 1000);

            } catch (err) {
                alert("Microphone access denied.");
                console.error(err);
            }

        }

        // STOP RECORDING
        else {
            mediaRecorder.stop();
        }

    });

});